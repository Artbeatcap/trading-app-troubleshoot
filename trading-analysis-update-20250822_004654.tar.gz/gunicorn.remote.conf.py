# Gunicorn configuration file
bind = "0.0.0.0:8000"
workers = 3
worker_class = "sync"
worker_connections = 1000
timeout = 30
keepalive = 2
max_requests = 1000
max_requests_jitter = 50
preload_app = True
reload = False
accesslog = "/var/log/trading-analysis/gunicorn_access.log"
errorlog = "/var/log/trading-analysis/gunicorn_error.log"
loglevel = "debug"
capture_output = True