#!/bin/bash
# Billing Management Fix Script

echo "Fixing Billing Management Issues..."

# 1. Check Stripe Customer Portal configuration
echo "1. Checking Stripe Customer Portal configuration..."
cd /home/tradingapp/trading-analysis
source venv/bin/activate

python3 -c "
import stripe
stripe.api_key = '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'
try:
    session = stripe.billing_portal.Session.create(
        customer='cus_test',
        return_url='https://example.com'
    )
except stripe.error.InvalidRequestError as e:
    if 'billing_portal' in str(e).lower():
        print('Customer Portal not configured in Stripe Dashboard')
        print('To fix: Go to Stripe Dashboard > Settings > Customer Portal')
        print('  - Enable Customer Portal')
        print('  - Configure allowed features (subscription management, payment methods)')
    else:
        print(f'Other error: {e}')
except Exception as e:
    print(f'Unexpected error: {e}')
"

# 2. Restart services to ensure billing routes are loaded
echo "2. Restarting services..."
sudo systemctl restart trading-analysis
sudo systemctl restart market-brief-scheduler

# 3. Check service status
echo "3. Checking service status..."
sudo systemctl status trading-analysis --no-pager
sudo systemctl status market-brief-scheduler --no-pager

# 4. Test billing endpoints
echo "4. Testing billing endpoints..."
curl -I https://optionsplunge.com/api/billing/pricing -k
curl -X POST https://optionsplunge.com/api/billing/create-checkout-session -H "Content-Type: application/json" -d '{"plan":"monthly"}' -k

echo "Billing fix script completed"

