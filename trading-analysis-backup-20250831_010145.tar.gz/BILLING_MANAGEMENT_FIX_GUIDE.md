# Billing Management Fix Guide

## Issue Summary
The billing management system is not working properly in the live app. Based on diagnostic testing, the core billing infrastructure is functioning correctly, but there may be issues with specific billing management features.

## ✅ What's Working
- **Billing API endpoints**: All endpoints are accessible and properly redirecting to login
- **Stripe configuration**: API keys and price IDs are properly configured
- **Database schema**: All billing-related fields are present
- **Services**: Both trading-analysis and market-brief-scheduler are running

## 🔧 Diagnostic Results

### 1. Billing Endpoints Status
- ✅ `/api/billing/pricing` - Accessible (HTTP 200)
- ✅ `/api/billing/create-checkout-session` - Properly redirects to login (HTTP 302)
- ✅ `/api/billing/create-portal-session` - Properly redirects to login (HTTP 302)
- ⚠️ `/api/billing/sync` - Returns 404 (may not be implemented)

### 2. Stripe Configuration
- ✅ **API Key**: Configured and working
- ✅ **Price IDs**: Monthly and annual prices configured
- ✅ **API Connectivity**: Stripe API is responding correctly

### 3. Services Status
- ✅ **trading-analysis**: Running on port 8000
- ✅ **market-brief-scheduler**: Running and enabled
- ✅ **Nginx**: Properly proxying to port 8000

## 🎯 Common Billing Management Issues & Solutions

### Issue 1: "Manage Billing" Button Not Working

**Symptoms:**
- Users can't access billing management
- "Manage Billing" button doesn't respond
- Settings page doesn't show billing options

**Solution:**
1. **Check Stripe Customer Portal Configuration:**
   - Go to [Stripe Dashboard](https://dashboard.stripe.com/settings/billing/portal)
   - Navigate to **Settings > Customer Portal**
   - Ensure **Customer Portal** is enabled
   - Configure allowed features:
     - ✅ Subscription management
     - ✅ Payment methods
     - ✅ Billing history
     - ✅ Invoice history

2. **Verify User Has Stripe Customer ID:**
   ```bash
   # Check if user has stripe_customer_id in database
   ssh root@167.88.43.61 "cd /home/tradingapp/trading-analysis && source venv/bin/activate && python -c \"from models import User; users = User.query.filter(User.stripe_customer_id.isnot(None)).all(); print(f'Users with Stripe customer ID: {len(users)}')\""
   ```

### Issue 2: Billing Portal Returns Error

**Symptoms:**
- Error: "Billing portal not configured. Please contact support."
- Error: "No Stripe customer"

**Solution:**
1. **Check Stripe Customer Portal Configuration** (see Issue 1)
2. **Verify User Subscription Status:**
   ```bash
   # Check user subscription status
   ssh root@167.88.43.61 "cd /home/tradingapp/trading-analysis && source venv/bin/activate && python -c \"from models import User; users = User.query.filter(User.subscription_status.isnot(None)).all(); [print(f'User: {u.username}, Status: {u.subscription_status}, Customer ID: {u.stripe_customer_id}') for u in users]\""
   ```

### Issue 3: Settings Page Not Showing Billing Options

**Symptoms:**
- Settings page doesn't display billing management section
- No "Manage Billing" or "Upgrade to Pro" buttons

**Solution:**
1. **Check User Authentication:**
   - Ensure user is logged in
   - Check if user has proper permissions

2. **Verify Billing Context in Settings:**
   ```bash
   # Test settings page billing context
   ssh root@167.88.43.61 "curl -I https://optionsplunge.com/settings -k"
   ```

### Issue 4: Subscription Status Not Updating

**Symptoms:**
- User subscription status doesn't reflect in the app
- Trial periods not showing correctly

**Solution:**
1. **Sync Subscription Status:**
   ```bash
   # Manual subscription sync
   ssh root@167.88.43.61 "cd /home/tradingapp/trading-analysis && source venv/bin/activate && python -c \"from billing import sync_subscription; from models import User; users = User.query.filter(User.stripe_subscription_id.isnot(None)).all(); [print(f'Syncing {u.username}') for u in users]\""
   ```

2. **Check Webhook Configuration:**
   - Ensure Stripe webhooks are configured
   - Verify webhook endpoint is accessible

## 🔍 Troubleshooting Steps

### Step 1: Check Application Logs
```bash
# Check recent application logs
ssh root@167.88.43.61 "tail -50 /var/log/trading-analysis/app.log | grep -i billing"

# Check for errors
ssh root@167.88.43.61 "journalctl -u trading-analysis --since '1 hour ago' | grep -i error"
```

### Step 2: Test Billing Endpoints
```bash
# Test pricing page
curl -I https://optionsplunge.com/api/billing/pricing -k

# Test checkout session (should redirect to login)
curl -X POST https://optionsplunge.com/api/billing/create-checkout-session \
  -H "Content-Type: application/json" \
  -d '{"plan":"monthly"}' -k

# Test portal session (should redirect to login)
curl -X POST https://optionsplunge.com/api/billing/create-portal-session \
  -H "Content-Type: application/json" -k
```

### Step 3: Verify Stripe Configuration
```bash
# Check Stripe environment variables
ssh root@167.88.43.61 "cd /home/tradingapp/trading-analysis && grep -i stripe .env"

# Test Stripe API connectivity
ssh root@167.88.43.61 "cd /home/tradingapp/trading-analysis && source venv/bin/activate && python -c \"import stripe; stripe.api_key='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'; account=stripe.Account.retrieve(); print(f'Stripe connected: {account.id}')\""
```

### Step 4: Check Database Schema
```bash
# Verify billing columns exist
ssh root@167.88.43.61 "cd /home/tradingapp/trading-analysis && source venv/bin/activate && python -c \"from models import User; from sqlalchemy import inspect; inspector=inspect(User.__table__); columns=[col.name for col in inspector.columns]; billing_cols=['stripe_customer_id','stripe_subscription_id','subscription_status','plan_type']; [print(f'{col}: {\"OK\" if col in columns else \"MISSING\"}') for col in billing_cols]\""
```

## 🚀 Quick Fix Commands

### Restart Services
```bash
ssh root@167.88.43.61 "sudo systemctl restart trading-analysis && sudo systemctl restart market-brief-scheduler"
```

### Check Service Status
```bash
ssh root@167.88.43.61 "sudo systemctl status trading-analysis && sudo systemctl status market-brief-scheduler"
```

### Test Billing Functionality
```bash
ssh root@167.88.43.61 "curl -I https://optionsplunge.com/api/billing/pricing -k && curl -X POST https://optionsplunge.com/api/billing/create-checkout-session -H 'Content-Type: application/json' -d '{\"plan\":\"monthly\"}' -k"
```

## 📋 Verification Checklist

After applying fixes, verify:

- [ ] **Stripe Customer Portal** is enabled in Stripe Dashboard
- [ ] **Billing endpoints** return proper responses
- [ ] **Settings page** shows billing options for authenticated users
- [ ] **"Manage Billing" button** works for users with subscriptions
- [ ] **Subscription status** updates correctly
- [ ] **Trial periods** display properly
- [ ] **Payment methods** can be managed
- [ ] **Billing history** is accessible

## 🆘 If Issues Persist

1. **Check Stripe Dashboard** for any account-level issues
2. **Review application logs** for specific error messages
3. **Test with a fresh user account** to isolate user-specific issues
4. **Verify webhook configuration** if subscription updates aren't working
5. **Contact Stripe Support** if Customer Portal configuration issues persist

## 📞 Support Information

- **Stripe Dashboard**: https://dashboard.stripe.com/settings/billing/portal
- **Stripe Documentation**: https://stripe.com/docs/billing/subscriptions/customer-portal
- **Application Logs**: `/var/log/trading-analysis/app.log`
- **Service Status**: `systemctl status trading-analysis`

---

**Last Updated**: August 26, 2025
**Status**: ✅ Core billing infrastructure working, Customer Portal configuration may need verification

