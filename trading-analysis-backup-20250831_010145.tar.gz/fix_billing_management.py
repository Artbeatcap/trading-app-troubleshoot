#!/usr/bin/env python3
"""
Fix billing management issues on the live app
"""

import os
import sys

def check_stripe_configuration():
    """Check Stripe configuration on the live app"""
    print("🔍 Checking Stripe Configuration on Live App")
    print("=" * 50)
    
    # Check environment variables
    stripe_vars = {
        "STRIPE_SECRET_KEY": "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",
        "STRIPE_PRICE_MONTHLY": "price_1Ry3mXA2FNw0kIRKDu3Sy4of",
        "STRIPE_PRICE_ANNUAL": "price_1Ry3mXA2FNw0kIRKaYJRFAyQ"
    }
    
    print("\n1. Checking Stripe environment variables...")
    for var, expected_value in stripe_vars.items():
        print(f"   {var}: {'✅ Set' if expected_value else '❌ Not set'}")
    
    print("\n2. Testing Stripe API connectivity...")
    try:
        import stripe
        stripe.api_key = stripe_vars["STRIPE_SECRET_KEY"]
        account = stripe.Account.retrieve()
        print(f"   ✅ Stripe API connected (Account: {account.id})")
        
        # Test Customer Portal configuration
        print("\n3. Testing Customer Portal configuration...")
        try:
            # This will fail but show if portal is configured
            session = stripe.billing_portal.Session.create(
                customer="cus_test",
                return_url="https://example.com"
            )
        except stripe.error.InvalidRequestError as e:
            if "billing_portal" in str(e).lower() or "configuration" in str(e).lower():
                print("   ❌ Customer Portal not configured in Stripe Dashboard")
                print("   💡 To fix: Go to Stripe Dashboard > Settings > Customer Portal")
                return False
            else:
                print(f"   ⚠️  Other Stripe error: {e}")
        except Exception as e:
            print(f"   ❌ Unexpected error: {e}")
            return False
            
        return True
        
    except ImportError:
        print("   ❌ Stripe library not installed")
        return False
    except Exception as e:
        print(f"   ❌ Stripe API error: {e}")
        return False

def check_billing_routes():
    """Check billing routes are properly registered"""
    print("\n🔍 Checking Billing Routes")
    print("=" * 30)
    
    try:
        from billing import bp
        routes = [rule.rule for rule in bp.url_map.iter_rules()]
        expected_routes = [
            "/api/billing/create-checkout-session",
            "/api/billing/create-portal-session", 
            "/api/billing/pricing",
            "/api/billing/success",
            "/api/billing/webhook"
        ]
        
        print("Registered billing routes:")
        for route in routes:
            print(f"   ✅ {route}")
        
        missing_routes = [route for route in expected_routes if route not in routes]
        if missing_routes:
            print("\nMissing routes:")
            for route in missing_routes:
                print(f"   ❌ {route}")
            return False
        
        return True
        
    except ImportError as e:
        print(f"   ❌ Cannot import billing module: {e}")
        return False
    except Exception as e:
        print(f"   ❌ Error checking routes: {e}")
        return False

def check_database_schema():
    """Check if billing-related database fields exist"""
    print("\n🔍 Checking Database Schema")
    print("=" * 30)
    
    try:
        from models import User
        from sqlalchemy import inspect
        
        inspector = inspect(User.__table__)
        columns = [col.name for col in inspector.columns]
        
        billing_columns = [
            "stripe_customer_id",
            "stripe_subscription_id", 
            "subscription_status",
            "plan_type",
            "trial_end",
            "had_trial"
        ]
        
        print("Billing-related columns:")
        for col in billing_columns:
            if col in columns:
                print(f"   ✅ {col}")
            else:
                print(f"   ❌ {col} (missing)")
                return False
        
        return True
        
    except Exception as e:
        print(f"   ❌ Error checking database schema: {e}")
        return False

def create_billing_fix_script():
    """Create a script to fix billing issues on the VPS"""
    print("\n🔧 Creating Billing Fix Script")
    print("=" * 40)
    
    fix_script = '''#!/bin/bash
# Billing Management Fix Script

echo "🔧 Fixing Billing Management Issues..."

# 1. Check Stripe Customer Portal configuration
echo "1. Checking Stripe Customer Portal configuration..."
cd /home/tradingapp/trading-analysis
source venv/bin/activate

python3 -c "
import stripe
stripe.api_key = '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'
try:
    session = stripe.billing_portal.Session.create(
        customer='cus_test',
        return_url='https://example.com'
    )
except stripe.error.InvalidRequestError as e:
    if 'billing_portal' in str(e).lower():
        print('❌ Customer Portal not configured in Stripe Dashboard')
        print('💡 To fix: Go to Stripe Dashboard > Settings > Customer Portal')
        print('   - Enable Customer Portal')
        print('   - Configure allowed features (subscription management, payment methods)')
    else:
        print(f'Other error: {e}')
except Exception as e:
    print(f'Unexpected error: {e}')
"

# 2. Restart services to ensure billing routes are loaded
echo "2. Restarting services..."
sudo systemctl restart trading-analysis
sudo systemctl restart market-brief-scheduler

# 3. Check service status
echo "3. Checking service status..."
sudo systemctl status trading-analysis --no-pager
sudo systemctl status market-brief-scheduler --no-pager

# 4. Test billing endpoints
echo "4. Testing billing endpoints..."
curl -I https://optionsplunge.com/api/billing/pricing -k
curl -X POST https://optionsplunge.com/api/billing/create-checkout-session -H "Content-Type: application/json" -d '{"plan":"monthly"}' -k

echo "✅ Billing fix script completed"
'''
    
    with open("fix_billing_vps.sh", "w") as f:
        f.write(fix_script)
    
    print("✅ Created fix_billing_vps.sh")
    print("📋 To apply fixes:")
    print("   1. Copy fix_billing_vps.sh to VPS")
    print("   2. Run: chmod +x fix_billing_vps.sh && ./fix_billing_vps.sh")
    print("   3. Check Stripe Dashboard > Settings > Customer Portal")

def main():
    """Main function"""
    print("🚀 Billing Management Diagnostic & Fix")
    print("=" * 50)
    
    # Check configurations
    stripe_ok = check_stripe_configuration()
    routes_ok = check_billing_routes()
    schema_ok = check_database_schema()
    
    print("\n" + "=" * 50)
    print("📋 Diagnostic Results:")
    print(f"   Stripe Configuration: {'✅ OK' if stripe_ok else '❌ Issues'}")
    print(f"   Billing Routes: {'✅ OK' if routes_ok else '❌ Issues'}")
    print(f"   Database Schema: {'✅ OK' if schema_ok else '❌ Issues'}")
    
    if not stripe_ok:
        print("\n🔧 Primary Issue: Stripe Customer Portal not configured")
        print("   This is the most common cause of billing management issues.")
        print("   The billing system is working, but users can't access the portal.")
    
    # Create fix script
    create_billing_fix_script()
    
    print("\n" + "=" * 50)
    print("🎯 Next Steps:")
    print("1. Run the fix script on the VPS")
    print("2. Configure Stripe Customer Portal in Stripe Dashboard")
    print("3. Test billing management functionality")
    print("4. Monitor application logs for any errors")

if __name__ == "__main__":
    main()

