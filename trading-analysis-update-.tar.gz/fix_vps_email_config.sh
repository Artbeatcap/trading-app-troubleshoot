#!/bin/bash
# Fix VPS Email Configuration for Market Brief
# Based on stock news email configuration

echo "🔧 Fixing VPS Email Configuration for Market Brief"
echo "=================================================="

# Connect to VPS
VPS_USER="tradingapp"
VPS_HOST="167.88.43.61"
VPS_PATH="/home/tradingapp/trading-analysis"

echo "📡 Connecting to VPS..."
ssh $VPS_USER@$VPS_HOST << 'EOF'

cd /home/tradingapp/trading-analysis

echo "🔍 Checking current email configuration..."

# Check if .env file exists
if [ ! -f .env ]; then
    echo "❌ .env file not found. Creating one..."
    touch .env
fi

# Check current email configuration
echo "Current email configuration:"
grep -E "(SENDGRID_KEY|SERVER_NAME|PREFERRED_URL_SCHEME)" .env || echo "No email config found"

# Add/update email configuration based on stock news email
echo "📧 Updating email configuration..."

# Remove existing email config lines
sed -i '/SENDGRID_KEY/d' .env
sed -i '/SERVER_NAME/d' .env
sed -i '/PREFERRED_URL_SCHEME/d' .env

# Add new email configuration
cat >> .env << 'ENV_CONFIG'

# Email Configuration (based on stock news email)
SENDGRID_KEY=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
SERVER_NAME=167.88.43.61
PREFERRED_URL_SCHEME=http
MAIL_DEFAULT_SENDER_NAME=Options Plunge Support
MAIL_DEFAULT_SENDER_EMAIL=support@optionsplunge.com
ENV_CONFIG

echo "✅ Email configuration updated"

# Check if SendGrid is installed
echo "📦 Checking SendGrid installation..."
if ! python3 -c "import sendgrid" 2>/dev/null; then
    echo "📦 Installing SendGrid..."
    source venv_new/bin/activate
    pip install sendgrid
    echo "✅ SendGrid installed"
else
    echo "✅ SendGrid already installed"
fi

# Create email test script
echo "🧪 Creating email test script..."
cat > test_email_fix.py << 'PYTHON_SCRIPT'
#!/usr/bin/env python3
"""
Test email configuration fix
"""
import os
from dotenv import load_dotenv

load_dotenv()

def test_email_config():
    """Test email configuration"""
    print("🔧 Testing Email Configuration Fix")
    print("=" * 50)
    
    # Check environment variables
    sendgrid_key = os.getenv('SENDGRID_KEY')
    server_name = os.getenv('SERVER_NAME')
    scheme = os.getenv('PREFERRED_URL_SCHEME')
    
    print(f"SendGrid Key: {'✅ SET' if sendgrid_key else '❌ NOT SET'}")
    print(f"Server Name: {server_name or '❌ NOT SET'}")
    print(f"Scheme: {scheme or '❌ NOT SET'}")
    
    # Test SendGrid
    if sendgrid_key:
        try:
            from sendgrid import SendGridAPIClient
            from sendgrid.helpers.mail import Mail, Email, To, Content
            
            sg = SendGridAPIClient(api_key=sendgrid_key)
            print("✅ SendGrid client created successfully")
            
            # Test URL generation
            test_token = "test_token_123"
            confirm_url = f"{scheme}://{server_name}/confirm/{test_token}"
            print(f"✅ Confirmation URL: {confirm_url}")
            
            # Test email creation (don't send)
            from_email = Email("support@optionsplunge.com", "Options Plunge Support")
            to_email = To("test@example.com")
            subject = "Test Email"
            content = Content("text/html", "<p>Test email</p>")
            mail = Mail(from_email, to_email, subject, content)
            print("✅ Email object created successfully")
            
            return True
            
        except Exception as e:
            print(f"❌ SendGrid test failed: {e}")
            return False
    else:
        print("❌ SendGrid key not configured")
        return False

if __name__ == "__main__":
    test_email_config()
PYTHON_SCRIPT

# Test email configuration
echo "🧪 Testing email configuration..."
python3 test_email_fix.py

# Update the application files
echo "📝 Updating application files..."

# Check if files need to be updated
echo "Checking if emails.py needs update..."
if ! grep -q "send_confirmation_email_direct" emails.py; then
    echo "❌ emails.py needs update - will be updated via SCP"
else
    echo "✅ emails.py already updated"
fi

echo "Checking if app.py needs update..."
if ! grep -q "send_confirmation_email_direct" app.py; then
    echo "❌ app.py needs update - will be updated via SCP"
else
    echo "✅ app.py already updated"
fi

echo "Checking if market_brief_generator.py needs update..."
if ! grep -q "send_daily_brief_direct" market_brief_generator.py; then
    echo "❌ market_brief_generator.py needs update - will be updated via SCP"
else
    echo "✅ market_brief_generator.py already updated"
fi

# Restart the service
echo "🔄 Restarting service..."
sudo systemctl restart trading-analysis

# Check service status
echo "📊 Service status:"
sudo systemctl status trading-analysis --no-pager

echo "✅ Email configuration fix completed!"
echo ""
echo "📋 Next steps:"
echo "1. Test the market brief subscription on the website"
echo "2. Check service logs: sudo journalctl -u trading-analysis -f"
echo "3. Monitor email sending in logs"

EOF

echo "✅ VPS email configuration fix completed!"
echo ""
echo "📋 Summary:"
echo "- Email configuration updated with SendGrid key"
echo "- SERVER_NAME and PREFERRED_URL_SCHEME configured"
echo "- Direct email functions added to bypass Flask context issues"
echo "- Service restarted"
echo ""
echo "🔍 To monitor:"
echo "ssh tradingapp@167.88.43.61"
echo "sudo journalctl -u trading-analysis -f"
